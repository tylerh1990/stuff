// Runs inside the devcontainer service against the disposable LDAP test profile.
// Exercises actual OIDC redirects, LDAP binds, catalog sync, and RBAC HTTP APIs.
import assert from 'node:assert/strict';

const backend = 'http://localhost:7007';
const frontend = 'http://localhost:3000';

async function login(username, password = 'test-only-user-password') {
  const cookies = new Map();
  async function request(url, options = {}) {
    let response;
    for (let hop = 0; hop < 20; hop += 1) {
      response = await fetch(url, {
        ...options,
        redirect: 'manual',
        headers: {
          ...options.headers,
          cookie: [...cookies].map(([k, v]) => `${k}=${v}`).join('; '),
        },
      });
      for (const cookie of response.headers.getSetCookie()) {
        const pair = cookie.split(';')[0];
        const index = pair.indexOf('=');
        cookies.set(pair.slice(0, index), pair.slice(index + 1));
      }
      if (response.status >= 300 && response.status < 400) {
        url = new URL(response.headers.get('location'), url).href;
        options = {};
        continue;
      }
      return { response, url, body: await response.text() };
    }
    throw new Error('Too many OIDC redirects');
  }

  const query = new URLSearchParams({
    env: 'development',
    origin: frontend,
    scope: 'openid profile email',
    flow: 'popup',
  });
  const page = await request(`${backend}/api/auth/oidc/start?${query}`);
  assert.equal(page.response.status, 200, 'OIDC must display the Dex login form');
  const action = page.body.match(/<form[^>]*action="([^"]*)"/i)?.[1];
  assert.notEqual(action, undefined, 'Dex login form must exist');
  const submitted = await request(
    new URL(action.replaceAll('&amp;', '&'), page.url).href,
    {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ login: username, password }),
    },
  );
  const encoded = submitted.body.match(/var authResponse = decodeURIComponent\('([^']+)'\)/)?.[1];
  if (!encoded) {
    assert.match(submitted.body, /invalid|incorrect/i, 'Dex must reject the bad password');
    return { error: { message: 'LDAP credentials rejected' } };
  }
  return JSON.parse(decodeURIComponent(encoded));
}

async function api(path, token, options = {}) {
  return fetch(`${backend}${path}`, {
    ...options,
    headers: { authorization: `Bearer ${token}`, ...options.headers },
  });
}

async function decisions(token) {
  const response = await api('/api/permission/authorize', token, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      items: [
        { id: 'read', resourceRef: 'component:default/example-website', permission: { type: 'resource', name: 'catalog.entity.read', attributes: { action: 'read' }, resourceType: 'catalog-entity' } },
        { id: 'create', permission: { type: 'basic', name: 'catalog.entity.create', attributes: { action: 'create' } } },
        { id: 'delete', resourceRef: 'component:default/example-website', permission: { type: 'resource', name: 'catalog.entity.delete', attributes: { action: 'delete' }, resourceType: 'catalog-entity' } },
        { id: 'run-template', permission: { type: 'basic', name: 'scaffolder.task.create', attributes: { action: 'create' } } },
      ],
    }),
  });
  const result = await response.json();
  assert.equal(response.status, 200, JSON.stringify(result));
  const { items } = result;
  return Object.fromEntries(items.map(item => [item.id, item.result]));
}

const discovery = await fetch('http://localhost:5556/dex/.well-known/openid-configuration');
assert.equal((await discovery.json()).issuer, 'http://localhost:5556/dex');
assert.equal((await fetch(frontend)).status, 200);

// LDAP scheduling/catalog processing is asynchronous on first startup.
let member;
for (let attempt = 0; attempt < 60; attempt += 1) {
  member = await login('jdoe');
  if (member.response?.backstageIdentity) break;
  if (attempt === 59) throw new Error(member.error?.message ?? 'Catalog user never became available');
  await new Promise(resolve => setTimeout(resolve, 2000));
}
const memberToken = member.response.backstageIdentity.token;
const identityResponse = await api('/api/auth/v1/userinfo', memberToken);
assert.equal(identityResponse.status, 200);
const identity = await identityResponse.json();
assert.equal(identity.claims.sub, 'user:default/jdoe');
assert.deepEqual(new Set(identity.claims.ent), new Set([
  'user:default/jdoe', 'group:default/platform', 'group:default/backstage-users',
]));
console.log('PASS: LDAP → Dex OIDC → catalog user and group ownership');

assert.deepEqual(await decisions(memberToken), {
  read: 'ALLOW', create: 'DENY', delete: 'DENY', 'run-template': 'DENY',
});
assert.equal((await api('/api/catalog/entities/by-name/user/default/jdoe', memberToken)).status, 200);
assert.equal((await api('/api/permission/roles', memberToken)).status, 403);
assert.equal((await api('/api/permission/', memberToken)).status, 403);
console.log('PASS: member can browse but cannot create/delete/run templates or administer RBAC');

const outsider = await login('outsider');
assert.ok(outsider.response?.backstageIdentity, 'Imported non-member can authenticate');
assert.deepEqual(await decisions(outsider.response.backstageIdentity.token), {
  read: 'ALLOW', create: 'DENY', delete: 'DENY', 'run-template': 'DENY',
});
assert.equal((await api('/api/permission/roles', outsider.response.backstageIdentity.token)).status, 403);
assert.equal((await api('/api/permission/', outsider.response.backstageIdentity.token)).status, 403);
console.log('PASS: authenticated catalog user without group membership has browse-only access');

const admin = await login('policy-admin');
assert.ok(admin.response?.backstageIdentity);
assert.equal((await api('/api/permission/roles', admin.response.backstageIdentity.token)).status, 200);
assert.deepEqual(await (await api('/api/permission/', admin.response.backstageIdentity.token)).json(), { status: 'Authorized' });
console.log('PASS: catalog admin group can administer RBAC');

const unimported = await login('unimported');
assert.ok(unimported.error, 'LDAP-authenticated user absent from catalog must be rejected');
assert.equal(unimported.response?.backstageIdentity, undefined);
assert.ok((await login('jdoe', 'incorrect-password')).error);
assert.ok((await fetch(`${backend}/api/auth/guest/refresh`)).status >= 400);
console.log('PASS: unimported user, wrong password, and guest authentication are rejected');
