import { AuthenticationError, NotFoundError } from '@backstage/errors';
import { dexSignInResolver } from './dexAuth';

describe('Dex catalog identity', () => {
  const signInWithCatalogUser = jest.fn();
  const ctx = { signInWithCatalogUser } as unknown as Parameters<
    typeof dexSignInResolver
  >[1];
  const info = (username: unknown) =>
    ({
      result: {
        fullProfile: {
          userinfo: {
            preferred_username: username,
            email: 'someone-else@example.test',
            groups: ['admins'],
          },
        },
      },
    }) as unknown as Parameters<typeof dexSignInResolver>[0];

  beforeEach(() => jest.resetAllMocks());

  it('uses only the catalog user and returns the catalog-derived identity', async () => {
    const result = { token: 'catalog-issued-token' };
    signInWithCatalogUser.mockResolvedValue(result);
    await expect(dexSignInResolver(info('JDoe'), ctx)).resolves.toBe(result);
    expect(signInWithCatalogUser).toHaveBeenCalledWith({
      entityRef: { kind: 'User', namespace: 'default', name: 'jdoe' },
    });
  });

  it.each([undefined, '', ' ', 'user:other/admin', 'jdoe@example.test', ['jdoe']])(
    'rejects invalid preferred_username %p',
    async username => {
      await expect(dexSignInResolver(info(username), ctx)).rejects.toBeInstanceOf(
        AuthenticationError,
      );
      expect(signInWithCatalogUser).not.toHaveBeenCalled();
    },
  );

  it('does not issue an identity when the catalog lookup fails', async () => {
    signInWithCatalogUser.mockRejectedValue(new NotFoundError('User not found'));
    await expect(dexSignInResolver(info('jdoe'), ctx)).rejects.toThrow(
      'User not found',
    );
  });
});
