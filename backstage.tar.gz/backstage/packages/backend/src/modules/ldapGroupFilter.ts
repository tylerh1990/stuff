import { createBackendModule } from '@backstage/backend-plugin-api';
import { makeValidator } from '@backstage/catalog-model';
import {
  defaultGroupTransformer,
  ldapOrgEntityProviderTransformsExtensionPoint,
} from '@backstage/plugin-catalog-backend-module-ldap';

const { isValidEntityName } = makeValidator();

/**
 * Keeps the whole-directory LDAP query while omitting AD groups whose
 * sAMAccountName cannot be represented as a Backstage entity name.
 */
export const ldapGroupFilterModule = createBackendModule({
  pluginId: 'catalog',
  moduleId: 'ldap-valid-group-filter',
  register(reg) {
    reg.registerInit({
      deps: {
        transforms: ldapOrgEntityProviderTransformsExtensionPoint,
      },
      async init({ transforms }) {
        transforms.setGroupTransformer(async (vendor, config, entry) => {
          const entity = await defaultGroupTransformer(vendor, config, entry);
          if (!entity || !isValidEntityName(entity.metadata.name)) {
            return undefined;
          }
          return entity;
        });
      },
    });
  },
});
