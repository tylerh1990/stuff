import { createBackendModule } from '@backstage/backend-plugin-api';
import { AuthenticationError } from '@backstage/errors';
import {
  authProvidersExtensionPoint,
  createOAuthProviderFactory,
  OAuthAuthenticatorResult,
  SignInResolver,
} from '@backstage/plugin-auth-node';
import {
  oidcAuthenticator,
  OidcAuthResult,
} from '@backstage/plugin-auth-backend-module-oidc-provider';

export const dexSignInResolver: SignInResolver<
  OAuthAuthenticatorResult<OidcAuthResult>
> = async (info, ctx) => {
  const username = info.result.fullProfile.userinfo.preferred_username;
  if (
    typeof username !== 'string' ||
    !/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,62}$/.test(username)
  ) {
    throw new AuthenticationError(
      'Dex must supply preferred_username from a valid AD sAMAccountName',
    );
  }

  // This rejects missing/ambiguous catalog users and delegates ownership
  // resolution to Backstage. Never trust OIDC groups or manufacture a user.
  return ctx.signInWithCatalogUser({
    entityRef: { kind: 'User', namespace: 'default', name: username.toLowerCase() },
  });
};

export const dexAuthModule = createBackendModule({
  pluginId: 'auth',
  moduleId: 'dex-oidc',
  register(reg) {
    reg.registerInit({
      deps: { providers: authProvidersExtensionPoint },
      async init({ providers }) {
        providers.registerProvider({
          providerId: 'oidc',
          factory: createOAuthProviderFactory({
            authenticator: oidcAuthenticator,
            signInResolver: dexSignInResolver,
          }),
        });
      },
    });
  },
});
