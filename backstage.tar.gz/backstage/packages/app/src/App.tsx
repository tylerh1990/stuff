import { createApp } from '@backstage/frontend-defaults';
import catalogPlugin from '@backstage/plugin-catalog/alpha';
import { navModule } from './modules/nav';
import { homeModule } from './modules/home';
import rbacPlugin from '@backstage-community/plugin-rbac';
import { dexAuthModule } from './modules/auth';

export default createApp({
  features: [catalogPlugin, rbacPlugin, navModule, homeModule, dexAuthModule],
});
