import {
  BackstageIdentityApi,
  OpenIdConnectApi,
  ProfileInfoApi,
  SessionApi,
} from '@backstage/core-plugin-api';
import { OAuth2 } from '@backstage/core-app-api';
import { SignInPage } from '@backstage/core-components';
import { SignInPageBlueprint } from '@backstage/plugin-app-react';
import {
  ApiBlueprint,
  configApiRef,
  createApiRef,
  createFrontendModule,
  discoveryApiRef,
  oauthRequestApiRef,
} from '@backstage/frontend-plugin-api';

export const dexAuthApiRef = createApiRef<
  OpenIdConnectApi & ProfileInfoApi & BackstageIdentityApi & SessionApi
>().with({ id: 'auth.dex' });

const dexAuthApi = ApiBlueprint.make({
  name: 'dex',
  params: defineParams =>
    defineParams({
      api: dexAuthApiRef,
      deps: {
        configApi: configApiRef,
        discoveryApi: discoveryApiRef,
        oauthRequestApi: oauthRequestApiRef,
      },
      factory: ({ configApi, discoveryApi, oauthRequestApi }) =>
        OAuth2.create({
          configApi,
          discoveryApi,
          oauthRequestApi,
          environment: configApi.getOptionalString('auth.environment'),
          provider: { id: 'oidc', title: 'Dex', icon: () => null },
          // Group authorization comes from the catalog, not Dex group claims.
          defaultScopes: ['openid', 'profile', 'email'],
        }),
    }),
});

const dexSignInPage = SignInPageBlueprint.make({
  params: {
    loader: async () => props => (
      <SignInPage
        {...props}
        provider={{
          id: 'dex',
          title: 'Dex',
          message: 'Sign in with your directory account',
          apiRef: dexAuthApiRef,
        }}
      />
    ),
  },
});

export const dexAuthModule = createFrontendModule({
  pluginId: 'app',
  extensions: [dexAuthApi, dexSignInPage],
});
