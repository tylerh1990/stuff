module.exports = {
  root: true,
};
