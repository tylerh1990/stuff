# Backstage development with Dex and Active Directory

This project develops a Backstage 1.55.0 app from the official
[`@backstage/create-app` scaffold](https://backstage.io/docs/getting-started/)
with Active Directory as the source of people and teams, Dex as the only
browser sign-in provider, and Backstage RBAC for permissions. VS Code Dev
Containers runs Backstage in the Node 24 Trixie image. The same
[Compose file](compose.yaml) starts Dex. The goal is for users to sign in with
their AD credentials, see their synced teams and team-owned products in the
catalog, and receive the appropriate access without manually maintaining
Backstage users or groups.

## How the pieces fit together

Backstage treats [authentication](https://backstage.io/docs/auth/),
[identity mapping](https://backstage.io/docs/auth/identity-resolver/), and
[authorization](https://backstage.io/docs/permissions/overview/) as separate
steps. This project connects them as follows:

1. **Catalog sync:** Backstage's
   [LDAP organization provider](https://backstage.io/docs/integrations/ldap/org/)
   reads AD users, groups, and memberships every five minutes. It creates
   catalog `User` and `Group` entities; it does not check browser passwords.
   The searches may cover the whole directory. A small provider transformer
   omits groups whose AD `sAMAccountName` cannot be a valid Backstage entity
   name, while keeping valid users, groups, and their relationships.
   A product can refer to a synced team with, for example,
   `spec.owner: group:default/platform`.
2. **Authentication:** The browser signs in through Dex. Dex finds the AD
   account and verifies its password over LDAP, then presents an OIDC identity
   to Backstage's standard OIDC auth provider. Backstage requests
   `offline_access`, stores the resulting Dex refresh token in an HTTP-only
   persistent cookie, and restores the session when the browser returns. Dex
   does not populate the Backstage catalog.
3. **Identity mapping:** A Backstage sign-in resolver takes Dex's
   `preferred_username` claim, populated from AD `sAMAccountName`, and finds
   the matching catalog User. Backstage issues a user identity such as
   `user:default/jdoe` with ownership references derived from that User's
   catalog group memberships, such as `group:default/platform`. If the User
   was not synced into the catalog, sign-in fails. Dex group claims are not
   used for this mapping.
4. **Authorization:** Backstage's permission backend delegates decisions to
   the community RBAC policy. Every signed-in catalog User receives the
   `role:default/authenticated-reader` role for read-only catalog and template
   browsing. Only members of the configured admin group can access the RBAC
   screen and management API. Group membership can also express ownership and
   support more specific policies later; it is not a prerequisite for ordinary
   browsing.

Authentication proves who the user is; the resolver determines which
Backstage identity that user has; authorization determines what that identity
may do. The catalog sync runs independently of sign-in and supplies the User
and Group records that connect those steps. RBAC applies to actions exposed
through Backstage's permission framework; each plugin must integrate with
that framework for its actions to be covered.

## Why this sign-in resolver exists

Backstage requires a sign-in resolver to map a successful Dex OIDC login to a
Backstage User. The built-in resolvers in the installed OIDC module match by
email or email local part; neither directly matches the AD `sAMAccountName`
that this catalog uses as each User's entity name. The small
[local resolver](packages/backend/src/modules/dexAuth.ts) reads Dex's
`preferred_username` claim, validates and lowercases it, then calls Backstage's
`signInWithCatalogUser` for the matching `user:default/<sAMAccountName>`.
Backstage performs the catalog lookup, issues the identity, and derives its
group ownership. A Dex-authenticated account without a matching catalog User
cannot sign in. This uses Backstage's standard OIDC authenticator and public
resolver extension point; it does not implement OIDC itself. Backstage
documents [custom OIDC resolvers](https://backstage.io/docs/auth/oidc/#resolvers)
and explains [why identity resolvers are needed](https://backstage.io/docs/auth/identity-resolver/#sign-in-resolvers).

## Configure your directory

Run `bash .devcontainer/initialize.sh` from the repository root, then edit the
ignored [local environment file](config/development.env) it creates. The script
generates separate random OIDC client and Backstage session secrets. Keep the
populated file private. The tracked [template](config/development.env.example)
explains the settings.

| Setting | What to supply |
| --- | --- |
| `LDAP_URL`, `DEX_LDAP_HOST` | Confirm the AD DNS name and LDAPS port. Both currently point to `dc01.hasapes.local:636`. |
| `DEX_LDAP_BIND_DN` / `DEX_LDAP_BIND_PASSWORD` | An account allowed to search users for Dex. |
| `LDAP_BIND_DN` / `LDAP_BIND_PASSWORD` | An account allowed to read users, groups, and membership for catalog sync. The same read-only account may serve both if it has both sets of access. |
| `LDAP_USER_BASE_DN`, `LDAP_GROUP_BASE_DN` | Actual search bases, narrowed to the intended people and groups. |
| `LDAP_USER_FILTER`, `LDAP_GROUP_FILTER` | Review the default AD filters. The user filter excludes disabled accounts. |
| `DEX_LDAP_EMAIL_ATTRIBUTE` | LDAP attribute Dex uses for its required OIDC email claim. `userPrincipalName` is the standard AD mapping and does not affect the `sAMAccountName` sign-in resolver. |
| `DEX_LDAP_CA_FILE`, `NODE_EXTRA_CA_CERTS` | For a private CA, put its PEM chain at `config/certs/ad-ca.pem` and set both values to `/etc/backstage/certs/ad-ca.pem`. Leave empty for a system-trusted CA. |
| `RBAC_ADMIN_GROUP` | Catalog ref of the AD group allowed to manage RBAC, such as `group:default/backstage-admins`. Group entity names come from AD group `sAMAccountName`. |

The local
[LDAP group transformer](packages/backend/src/modules/ldapGroupFilter.ts) uses
the provider's supported transform extension point and Backstage's own entity
name validator. Returning `undefined` is the provider's standard way to ignore
an LDAP entry. An ignored group does not appear in the catalog, and relations
through that group are omitted; direct membership in valid groups still
resolves. This avoids catalog policy errors from directory groups with spaces
or other unsupported characters without narrowing the directory search.

Dex can omit its service-account bind only if the directory allows anonymous
user searches. Your directory does not, so Dex needs a search account to find
the user DN before trying the user's password. Catalog sync also needs a read
account. One least-privilege account can serve both if its access covers both
searches.

## Start developing

1. Install Docker and VS Code with the **Dev Containers** extension. Give
   Docker at least 6 GB of memory and 20 GB of disk space.
2. Open this repository in VS Code and choose **Dev Containers: Reopen in
   Container**. Initialization creates ignored local config if needed. The
   container installs dependencies with the checked-in Yarn 4 release.
3. Fill the AD and admin-group settings above. After changing Dex settings or
   its environment file, reload only Dex with
   `docker compose up -d --no-deps --force-recreate dex`; `--no-deps` prevents
   Compose from replacing the active Dev Container. Run `yarn start` inside
   the dev container.
4. Forward ports **3000**, **7007**, and **5556** to the same local ports in VS
   Code. Open <http://localhost:3000> and select **Dex**. Dex's OIDC issuer and
   callback use `localhost`, so a different forwarded port or a browser on
   another machine requires matching configuration changes.

Normal startup does not run the test LDAP service. Until AD is configured,
Dex and catalog sync cannot authenticate against your directory. There is no
guest sign-in or allow-all policy. The catalog still includes a demo component
and template; users and groups come only from LDAP. Local SQLite and Dex
signing/session state are in memory and reset on restart, so restarting Dex
invalidates existing refresh-token cookies. The RBAC UI is installed;
its navigation item appears only for authorized admins, and its page and API
reject other users.

The `integration-test` Compose profile and [test files](tests/integration)
provide a disposable fictional directory. They exercise LDAP → Dex → catalog
→ RBAC but cannot validate your actual AD bases, privileges, groups, DNS, or
CA chain.

## Compatibility and development notes

The Trixie Docker feature uses `moby: false` because Moby packages are not
available there; the Docker CE client connects to the host daemon. The backend
pins `better-sqlite3` to 13.0.3 because the scaffold's 12.x addon crashed on
Node 24.21.0. Backstage 1.55.0 still declares a 12.x peer range, so Yarn emits
a peer warning. The RBAC plugin's TypeORM adapter also needs its MongoDB peer
dependency declared through a Yarn package extension even with SQLite.

The workspace has the same absolute path inside and outside the container so
the host Docker daemon can mount TechDocs build files. On Windows, open the
checkout from WSL and share it with Docker Desktop. `TMPDIR` points to ignored
`.cache/tmp`. TechDocs retains the scaffold's Docker generator.

Useful commands inside the dev container:

```sh
yarn start
yarn tsc
yarn workspace backend test --watch=false --runInBand
yarn lint:all
yarn build:backend
```

If startup prints repeated `backend-dev-utils`/`DevDataStore` `EPIPE` errors,
check `cat /sys/fs/cgroup/memory.events` inside the container. A nonzero or
increasing `oom_kill` count means the Docker host killed the parent or frontend
compiler for lack of memory; the SQLite messages are only a consequence of
that lost IPC channel. Increase the Docker host or VM to at least 6 GB of RAM
(8 GB is preferable), or configure host swap, then rebuild/restart the Dev
Container before running `yarn start` again. Restarting also removes any
orphaned backend left by the OOM kill. The startup note about not computing a
Git version is harmless while this new repository has no commit.

This integration follows the [Backstage LDAP catalog](https://backstage.io/docs/integrations/ldap/org/),
[Backstage OIDC authentication](https://backstage.io/docs/auth/oidc/),
[Dex LDAP connector](https://dexidp.io/docs/connectors/ldap/), and
[community RBAC backend](https://github.com/backstage/community-plugins/tree/main/workspaces/rbac/plugins/rbac-backend)
documentation. The custom code is the `sAMAccountName` catalog sign-in
resolver, the invalid LDAP group filter, and the frontend
`SignInPageBlueprint` module.
