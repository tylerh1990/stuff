#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
umask 077

if [[ ! -f .env ]]; then
  printf 'BACKSTAGE_WORKSPACE_PATH=%s\nBACKSTAGE_ENV_FILE=./config/development.env\n' "$(pwd -P)" > .env
fi

if [[ ! -f config/development.env ]]; then
  command -v openssl >/dev/null || { echo 'Install openssl to generate local OIDC secrets.' >&2; exit 1; }
  client_secret=$(openssl rand -hex 32)
  session_secret=$(openssl rand -hex 32)
  sed -e "s/GENERATE_OIDC_SECRET/$client_secret/" \
      -e "s/GENERATE_SESSION_SECRET/$session_secret/" \
      config/development.env.example > config/development.env
fi

echo 'Local configuration ready. Fill in AD settings and the RBAC admin group in config/development.env.'
